# Logseq Query Exporter Plugin

A plugin for Logseq that allows you to run a query and export the results to markdown.

<img src="screenshot.png">
